package com.example.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
@Entity
public class Customer {
	@Id
	@GeneratedValue
	private int id;
    private String card_type ; 
    private String title ; 
    private String name ; 
    private String d_o_b ; 
    private String sex ;
	private String Adress ; 
    private String limit_amt ;
    
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCard_type() {
		return card_type;
	}
	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getD_o_b() {
		return d_o_b;
	}
	public void setD_o_b(String d_o_b) {
		this.d_o_b = d_o_b;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAdress() {
		return Adress;
	}
	public void setAdress(String adress) {
		Adress = adress;
	}
	public String getLimit_amt() {
		return limit_amt;
	}
	public void setLimit_amt(String limit_amt) {
		this.limit_amt = limit_amt;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", card_type=" + card_type + ", title=" + title + ", name=" + name + ", d_o_b="
				+ d_o_b + ", sex=" + sex + ", Adress=" + Adress + ", limit_amt=" + limit_amt + "]";
	}
	
	
 
}

